
-- Drop tables if they already exist
DROP TABLE IF EXISTS question;
DROP TABLE IF EXISTS user;

-- Create question table
CREATE TABLE question (
    SNO INT PRIMARY KEY,
    quest VARCHAR(255),
    CORRECT_ANS VARCHAR(100),
    OPTION1 VARCHAR(100),
    OPTION2 VARCHAR(100),
    OPTION3 VARCHAR(100)
);

INSERT INTO question VALUES
(1, 'What is the correct file extension for Python files?', '.py', '.python', '.pt', '.txt'),
(2, 'Which of these is an immutable data type in Python?', 'Tuple', 'List', 'Dictionary', 'Set'),
(3, 'Which keyword is used to define a function in Python?', 'def', 'func', 'lambda', 'method'),
(4, 'Which of the following is a conditional statement in Python?', 'if', 'switch', 'case', 'when'),
(5, 'Which of the following is used to import a module in Python?', 'import', 'load', 'include', 'require'),
(6, 'Which mode is used to open a file for reading in Python?', 'r', 'w', 'a', 'x'),
(7, 'Which keyword is used to handle exceptions in Python?', 'try', 'catch', 'finally', 'except'),
(8, 'Which data structure does Python use for key-value pairs?', 'Dictionary', 'List', 'Tuple', 'Set'),
(9, 'Which keyword is used to create a class in Python?', 'class', 'object', 'struct', 'module'),
(10, 'Which of the following represents a loop in Python?', 'while', 'for', 'do', 'repeat'),
(11, 'What does the len() function do in Python?', 'Returns length', 'Finds maximum', 'Finds minimum', 'Adds elements'),
(12, 'How do you comment a single line in Python?', '#', '//', '/* */', '--'),
(13, 'What is the output of 3**2 in Python?', '9', '6', '8', 'None'),
(14, 'Which function is used to convert a string to lowercase?', 'lower()', 'upper()', 'capitalize()', 'split()'),
(15, 'Which keyword is used to exit a loop in Python?', 'break', 'exit', 'stop', 'pass'),
(16, 'What is the purpose of the range() function in Python?', 'Generate sequence of numbers', 'Sort numbers', 'Find range of list', 'Add numbers'),
(17, 'Which method is used to add an element to a list?', 'append()', 'add()', 'insert()', 'push()'),
(18, 'What is the correct syntax to define a dictionary?', '{"key": "value"}', '[key, value]', 'key -> value', '(key, value)'),
(19, 'How can you catch multiple exceptions in Python?', 'Use multiple except blocks', 'Use multiple try blocks', 'Use pass', 'Use finally block'),
(20, 'Which module in Python is used for math functions?', 'math', 'random', 'os', 'sys');

-- Create user table
CREATE TABLE user (
    USER_ID INT PRIMARY KEY,
    NAME VARCHAR(50),
    SCORE INT
);

INSERT INTO user VALUES
(101, 'David', 1),
(102, 'RAM', 3),
(103, 'Rohit', 1),
(104, 'sashwanth', 0),
(105, 'Dev', 6),
(106, 'Tarun', 2);
