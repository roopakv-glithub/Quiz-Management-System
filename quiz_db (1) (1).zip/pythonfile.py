import mysql.connector as mycon
import random

# Establishing connection
con = mycon.connect(host="localhost", user="root", passwd="roopak", database="quiz")
cur = con.cursor()

def register():
    name = input("Enter your name: ")
    cur.execute("insert into player(name, score) values('{}', 0)".format(name))
    con.commit()
    print("Registration successful!\n")

def start_quiz():
    name = input("Enter your name: ")
    cur.execute("select * from question order by rand() limit 5")
    data = cur.fetchall()
    score = 0
    for i in data:
        print("\nQ.", i[0])
        print("a)", i[1], " b)", i[2], " c)", i[3], " d)", i[4])
        ans = input("Enter your answer: ")
        if ans.lower() == i[5].lower():
            print("Correct!")
            score += 1
        else:
            print("Wrong! Correct answer is", i[5])
    cur.execute("update player set score=score+{} where name='{}'".format(score, name))
    con.commit()
    print("\nYour Score:", score)

def view_score():
    cur.execute("select * from player")
    data = cur.fetchall()
    print("\nName\tScore")
    for i in data:
        print(i[0], "\t", i[1])

while True:
    print("\n----- QUIZ MANAGEMENT SYSTEM -----")
    print("1. Register")
    print("2. Start Quiz")
    print("3. View Scores")
    print("4. Exit")
    ch = int(input("Enter your choice: "))
    if ch == 1:
        register()
    elif ch == 2:
        start_quiz()
    elif ch == 3:
        view_score()
    elif ch == 4:
        print("Exiting... Thank you for playing!")
        break
    else:
        print("Invalid choice!")